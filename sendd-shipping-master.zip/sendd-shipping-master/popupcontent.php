<div id="popup_content" style="display:none;">
  <div class="popup_close"><a href="javascript:void(0)" onclick="closepopup();"> Close</a></div>

</div>
