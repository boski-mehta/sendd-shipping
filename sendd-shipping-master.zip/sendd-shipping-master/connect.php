<!-- HTML Content for Product  START      -->

<div class="product-card-clearfix">
            <div class="product-card-container">

                      <div class="connect-image-container">
                            <div>
                                <div class="connect-image shopify-icon">

                                </div>
                                <span class="cc-text-medium">SHOPIFY</span>
                           </div>
                      </div>

                      <button type='button' class='btn grey-button' id='shopify-connect-button'><i class='fa fa-check' aria-hidden='true'></i> Connected</button>
            </div>
 </div>

 <div class="product-card-clearfix">
             <div class="product-card-container">

                       <div class="connect-image-container">
                              <div>
                                   <div class="connect-image buffer-icon">

                                   </div>
                                   <span class="cc-text-medium">BUFFER</span>
                              </div>
                       </div>

                       <button type='button' class='btn green-button' id='shopify-connect-button'><i class='fa fa-sign-in' aria-hidden='true'></i> Connect</button>
             </div>
  </div>

<!-- Show / Hide Product Details -->
